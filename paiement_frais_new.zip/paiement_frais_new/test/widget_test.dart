import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:paiement_frais/main.dart'; // Assure-toi que le nom du projet est correct

void main() {
  testWidgets('Login screen loads', (WidgetTester tester) async {
    await tester
        .pumpWidget(const MyApp()); // ✅ Ajout de const pour les performances

    // Vérifie que le bouton "Se connecter" est bien affiché
    expect(find.text('Se connecter'), findsOneWidget);

    // Vérifie qu'il y a deux champs TextField (email + mot de passe)
    expect(find.byType(TextField), findsNWidgets(2));
  });
}
