package com.example.paiement_frais_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
