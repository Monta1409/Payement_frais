import 'package:flutter/foundation.dart';
import '../models/payment.dart';

class PaymentProvider extends ChangeNotifier {
  List<Payment> _payments = [];

  List<Payment> get payments => _payments;

  void setPayments(List<Payment> list) {
    _payments = list;
    notifyListeners();
  }

  void addPayment(Payment payment) {
    _payments.add(payment);
    notifyListeners();
  }
}
