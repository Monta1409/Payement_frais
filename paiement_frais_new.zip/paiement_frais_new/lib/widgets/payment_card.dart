import 'package:flutter/material.dart';
import '../../models/payment.dart';

class PaymentCard extends StatelessWidget {
  final Payment payment;

  const PaymentCard({super.key, required this.payment}); // ✅ super.key utilisé

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: ListTile(
        title: Text('${payment.amount} €'),
        subtitle: Text('Date : ${payment.dueDate}'),
        trailing: Text(payment.status),
      ),
    );
  }
}
