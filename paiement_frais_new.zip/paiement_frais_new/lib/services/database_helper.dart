import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/user.dart';
import '../models/payment.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('app.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        password TEXT,
        role TEXT
      );
    ''');

    await db.execute('''
      CREATE TABLE payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        amount REAL,
        due_date TEXT,
        status TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id)
      );
    ''');
  }

  // CRUD utilisateurs
  Future<int> insertUser(User user) async {
    final db = await instance.database;
    return await db.insert('users', user.toMap());
  }

  Future<User?> getUserByEmail(String email) async {
    final db = await instance.database;
    final maps =
        await db.query('users', where: 'email = ?', whereArgs: [email]);
    if (maps.isNotEmpty) return User.fromMap(maps.first);
    return null;
  }

  Future<List<User>> getAllUsers() async {
    final db = await instance.database;
    final maps = await db.query('users');
    return maps.map((map) => User.fromMap(map)).toList();
  }

  Future<int> countUsers() async {
    final db = await instance.database;
    final x = await db.rawQuery('SELECT COUNT(*) FROM users');
    return Sqflite.firstIntValue(x) ?? 0;
  }

  // Paiements
  Future<int> insertPayment(Payment payment) async {
    final db = await instance.database;
    return await db.insert('payments', payment.toMap());
  }

  Future<List<Payment>> getPaymentsByUser(int userId) async {
    final db = await instance.database;
    final maps =
        await db.query('payments', where: 'user_id = ?', whereArgs: [userId]);
    return maps.map((map) => Payment.fromMap(map)).toList();
  }

  Future<List<Payment>> getAllPayments() async {
    final db = await instance.database;
    final maps = await db.query('payments');
    return maps.map((map) => Payment.fromMap(map)).toList();
  }

  Future<int> countPaymentsByStatus(String status) async {
    final db = await instance.database;
    final x = await db
        .rawQuery('SELECT COUNT(*) FROM payments WHERE status = ?', [status]);
    return Sqflite.firstIntValue(x) ?? 0;
  }
}
