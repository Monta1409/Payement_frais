import '../models/user.dart';
import 'database_helper.dart';

class AuthService {
  Future<User?> loginUser(String email, String password) async {
    final user = await DatabaseHelper.instance.getUserByEmail(email);
    if (user != null && user.password == password) {
      return user;
    }
    return null;
  }
}
