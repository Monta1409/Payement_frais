class Payment {
  final int? id;
  final int userId;
  final double amount;
  final String dueDate;
  final String status; // 'paid' or 'unpaid'

  Payment(
      {this.id,
      required this.userId,
      required this.amount,
      required this.dueDate,
      required this.status});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'user_id': userId,
      'amount': amount,
      'due_date': dueDate,
      'status': status,
    };
  }

  factory Payment.fromMap(Map<String, dynamic> map) {
    return Payment(
      id: map['id'],
      userId: map['user_id'],
      amount: map['amount'],
      dueDate: map['due_date'],
      status: map['status'],
    );
  }
}
