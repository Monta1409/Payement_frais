import 'package:flutter/material.dart';
import 'screens/login_screen.dart';

void main() {
  runApp(const MyApp()); // ✅ Ajout de `const`
}

class MyApp extends StatelessWidget {
  const MyApp({super.key}); // ✅ Ajout de `key`

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Paiement Frais',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const LoginScreen(),
    );
  }
}
