import 'package:flutter/material.dart';
import '../../../models/user.dart';

class StudentProfile extends StatelessWidget {
  final User user;

  const StudentProfile({super.key, required this.user}); // ✅ ligne 7 corrigée

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Nom : ${user.name}'),
            Text('Email : ${user.email}'),
            Text('Rôle : ${user.role}'),
          ],
        ),
      ),
    );
  }
}
