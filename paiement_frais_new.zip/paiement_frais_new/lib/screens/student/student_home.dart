import 'package:flutter/material.dart';
import '../../../models/user.dart';
import 'payment_list.dart';
import 'student_profile.dart';

class StudentHome extends StatelessWidget {
  final User user;

  const StudentHome({super.key, required this.user}); // ✅ super.key utilisé

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Accueil Étudiant'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Bienvenue, ${user.name}'),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PaymentList(userId: user.id!),
                  ),
                );
              },
              child: const Text('Mes Paiements'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => StudentProfile(user: user),
                  ),
                );
              },
              child: const Text('Mon Profil'),
            ),
          ],
        ),
      ),
    );
  }
}
