import 'package:flutter/material.dart';
import '../../../models/payment.dart';
import '../../../services/database_helper.dart';
import 'payment_detail.dart';
import '../../../widgets/payment_card.dart'; // ✅ corrigé

class PaymentList extends StatelessWidget {
  final int userId;

  const PaymentList({super.key, required this.userId}); // ✅ super.key utilisé

  Future<List<Payment>> _fetchPayments() async {
    return await DatabaseHelper.instance.getPaymentsByUser(userId);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mes Paiements')),
      body: FutureBuilder<List<Payment>>(
        future: _fetchPayments(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final payments = snapshot.data!;
          return ListView.builder(
            itemCount: payments.length,
            itemBuilder: (context, index) {
              final payment = payments[index];
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PaymentDetail(payment: payment),
                  ),
                ),
                child: PaymentCard(payment: payment),
              );
            },
          );
        },
      ),
    );
  }
}
