import 'package:flutter/material.dart';
import '../../../models/payment.dart';

class PaymentDetail extends StatelessWidget {
  final Payment payment;

  const PaymentDetail({super.key, required this.payment});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Détail Paiement')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Montant : ${payment.amount} €'),
            Text('Date limite : ${payment.dueDate}'),
            Text('Statut : ${payment.status}'),
          ],
        ),
      ),
    );
  }
}
