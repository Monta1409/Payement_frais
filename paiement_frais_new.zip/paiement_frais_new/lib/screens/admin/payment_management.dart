import 'package:flutter/material.dart';
import '../../../models/payment.dart'; // ← adapte le chemin si besoin
import '../../../services/database_helper.dart'; // ← adapte le chemin si besoin

class PaymentManagement extends StatelessWidget {
  const PaymentManagement({super.key});

  Future<List<Payment>> _fetchPayments() =>
      DatabaseHelper.instance.getAllPayments();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Paiements')),
      body: FutureBuilder<List<Payment>>(
        future: _fetchPayments(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final payments = snapshot.data!;
          return ListView.builder(
            itemCount: payments.length,
            itemBuilder: (context, index) => ListTile(
              title: Text('Montant : ${payments[index].amount} €'),
              subtitle: Text('Statut : ${payments[index].status}'),
            ),
          );
        },
      ),
    );
  }
}
