import 'package:flutter/material.dart';
import '../../../models/user.dart';
import '../../../services/database_helper.dart';

class UserManagement extends StatelessWidget {
  const UserManagement({super.key});

  Future<List<User>> _fetchUsers() => DatabaseHelper.instance.getAllUsers();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Utilisateurs')),
      body: FutureBuilder<List<User>>(
        future: _fetchUsers(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final users = snapshot.data!;
          return ListView.builder(
            padding: const EdgeInsets.all(8.0),
            itemCount: users.length,
            itemBuilder: (context, index) => ListTile(
              title: Text(users[index].name),
              subtitle: Text(users[index].email),
              trailing: Text(users[index].role),
            ),
          );
        },
      ),
    );
  }
}
