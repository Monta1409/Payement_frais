import 'package:flutter/material.dart';
import '../../../services/database_helper.dart'; // ✅ adapte ce chemin si besoin

class StatisticsScreen extends StatelessWidget {
  const StatisticsScreen({super.key}); // ✅ simplifié avec `super.key`

  Future<Map<String, dynamic>> _getStats() async {
    final totalUsers = await DatabaseHelper.instance.countUsers();
    final paid = await DatabaseHelper.instance.countPaymentsByStatus('paid');
    final unpaid =
        await DatabaseHelper.instance.countPaymentsByStatus('unpaid');
    return {
      'totalUsers': totalUsers,
      'paid': paid,
      'unpaid': unpaid,
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Statistiques')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: _getStats(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final stats = snapshot.data!;
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Total utilisateurs : ${stats['totalUsers']}'),
                Text('Paiements réglés : ${stats['paid']}'),
                Text('Paiements non réglés : ${stats['unpaid']}'),
              ],
            ),
          );
        },
      ),
    );
  }
}
